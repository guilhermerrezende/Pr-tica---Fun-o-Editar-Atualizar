<?php

namespace App\Http\Enums;

enum TamanhoEnum: string
{
    case grande = 'grande';
    case media = 'media';
    case pequena = 'pequena';
}